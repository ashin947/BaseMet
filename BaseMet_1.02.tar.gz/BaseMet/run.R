#' Title
#'
#'
#' @return
#' @export
#'
#' @examples


#' library("devtools")
#' usethis::create_package("BaseMet")
use_readme_rmd()
install.packages("devtools")
library(devtools)
devtools::build()
#install.packages("roxygen2")
library(roxygen2)



input_martix="test.xlsx"
ALLsample="ALLTYPE.txt"
group_sample="TYPE.txt"
foldChange=0.585
padj=0.05
SELECT="PValue"
group_meta="Type2.xlsx"
usethis::use_r("pca_plot")
use_package("ggplot2")
use_package("readxl")
use_package("ggrepel")
use_package("tidyverse")
use_package("RColorBrewer")
use_package("ggsci")
use_package("stringr")
use_package("PerformanceAnalytics")
use_package("reshape2")
use_package("qpdf")
use_package("pheatmap")
use_package("showtext")
use_package("corrplot")
use_package("Matrix")
use_package("ggraph")
use_package("igraph")
use_package("clusterProfiler")
use_package("enrichplot")


devtools::load_all()##运行再build
usethis::use_r("call_diff")
usethis::use_r("QC_plot")
usethis::use_r("heatmap_cor")
usethis::use_r("pie_plot")
usethis::use_r("ggraph_plot")
usethis::use_r("kegg_plot")

usethis::use_mit_license()
devtools::check()
######################################################
pca_plot(input_martix,ALLsample)

call_diff(group_sample, input_martix)
heatmap_cor(group_sample, input_martix,group_meta)
pie_plot(group_meta)
QC_plot(group_sample, input_martix)
#**************************************************************
ggraph_plot(input_martix,group_meta,group_sample)
#######***************************************************************
kegg_plot(input_martix,group_meta,group_sample)
