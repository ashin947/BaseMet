#' Title
#' @param group_meta
#' @return
#' @export
#'
#' @examples

pie_plot <- function(group_meta){
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)
  Type2=read_excel(group_meta,sheet = "Sheet1")
  Type2=as.data.frame(Type2)

  for (i in 1:nrow(Type2) ){
    x=Type2[i,2]  # ??????
    a=gsub('["]', '', x)  #????????????
    Type2[i,2]=a  #?????????????????????
  }
  for (i in 1:nrow(Type2) ){
    x=Type2[i,3]  # ??????
    a=gsub('["]', '', x)  #????????????
    Type2[i,3]=a  #?????????????????????
  }
  groupcolor <- color74[1:length(unique( Type2[,3]))]

  V1=c("Type")
  options(digits = 2)
  pie=as.data.frame(unique( Type2[,3]))
  pie=cbind(pie,0)
  for( i in 1:nrow( pie)){
    for(j in 1:nrow(Type2)){
      if(pie[i,1]==Type2[j,3]){pie[i,2]=pie[i,2]+1}

    }
  }
  parent=pie[,2]*100/nrow(Type2)
  pie=cbind(pie,parent)

  name=paste(pie[,1],"(",round( pie[,3],2),"%)",sep="")
  pie=cbind(pie,name)
  colnames(pie)[2]="count"
  pie$name= factor(pie$name, levels=pie$name)

  p1=ggplot(data=pie,aes(x='',y=count,fill=name))+ theme_bw() +
    geom_bar(stat="identity", color="white",width = 20)+ coord_polar(theta = "y",start=0)+ labs(x = "", y = "", title = "") + theme(axis.text = element_blank())+
    scale_fill_discrete(labels = name)+theme(axis.ticks = element_blank())+ggtitle("Class")+theme(plot.title = element_text(hjust = 0.5)) + labs(fill = "")+
    theme(panel.grid=element_blank()) +    ## 去掉白色圆框和中间的坐标线
    theme(panel.border=element_blank())   ## 去掉最外层正方形的框框

  #p1
  #ggsave(filename = "KEGGdotplot.tiff", plot = p1, dpi = 400, width = 12.5, height = 13)
  ggsave(filename = "PIE-subclass.pdf", plot = p1, dpi = 400, width = 12.5, height = 13)

  groupcolor <- color74[1:length(unique( Type2[,3]))]

  V1=c("Type")
  options(digits = 2)
  pie=as.data.frame(unique( Type2[,2]))
  pie=cbind(pie,0)
  for( i in 1:nrow( pie)){
    for(j in 1:nrow(Type2)){
      if(pie[i,1]==Type2[j,2]){pie[i,2]=pie[i,2]+1}

    }
  }
  parent=pie[,2]*100/nrow(Type2)
  pie=cbind(pie,parent)

  name=paste(pie[,1],"(",round( pie[,3],2),"%)",sep="")
  pie=cbind(pie,name)
  colnames(pie)[2]="count"
  pie$name= factor(pie$name, levels=pie$name)

  p1=ggplot(data=pie,aes(x='',y=count,fill=name))+ theme_bw() +
    geom_bar(stat="identity", color="white",width = 20)+ coord_polar(theta = "y",start=0)+ labs(x = "", y = "", title = "") + theme(axis.text = element_blank())+
    scale_fill_discrete(labels = name)+theme(axis.ticks = element_blank())+ggtitle("Class")+theme(plot.title = element_text(hjust = 0.5)) + labs(fill = "")+
    theme(panel.grid=element_blank()) +    ## 去掉白色圆框和中间的坐标线
    theme(panel.border=element_blank())   ## 去掉最外层正方形的框框

  #p1
  #ggsave(filename = "KEGGdotplot.tiff", plot = p1, dpi = 400, width = 12.5, height = 13)
  ggsave(filename = "PIE-mainclass.pdf", plot = p1, dpi = 400, width = 12.5, height = 13)
}
