#' Title
#' @param group_meta
#' @param input_martix
#' @param group_sample
#' @return
#' @export
#'
#' @examples


ggraph_plot <- function(input_martix,group_meta,group_sample){
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)
  library(tidyverse)
  library(igraph)
  library(ggraph)
  library(tidygraph)
  library(Matrix)
  Type=read.table(group_sample,header = F,sep = "\t",check.names=F)
  aaa=paste(Type[nrow(Type),2],"vs",Type[1,2],sep="_")
  ###1. 读入数据
  #aaa=str_split(input_martix,'[.]',simplify = T)[,c(1,2)]
  new=paste(aaa,"cor_graph.txt",sep="_")
  result3=read.table(paste( aaa,new,sep="/"),sep = "\t",check.names = F,quote = "",header = T)
  colnames(result3)=c("from","to","cor","p")
  result3=result3[result3$p<0.05, ]
  result3=result3[(result3$cor>0.8 | result3$cor < -0.8), ]
  #result3=result3[result3$cor<= -0.8, ]
  #节点数据
  m_data=result3
  nodes <- data.frame(name = unique(union(m_data$from, m_data$to)))
  #nodes$survival_impact <- m_data$co
  Type2=read_excel(group_meta,sheet = "Sheet1")
  Type2=as.data.frame(Type2)

  rownames(Type2)=Type2[,1]
  Type2=Type2[,-1]
  for (i in 1:nrow(Type2) ){
    x=Type2[i,3]  # 赋值
    a=gsub('["]', '', x)  #去双引号
    Type2[i,3]=a  #给矩阵重新赋值
  }
  rownames(Type2)=Type2[,3]
  Type2=Type2[nodes[,1],]
  nodes$cluster <- Type2[,2]
  #边数据
  edges <- m_data[c("from","to","cor")]
  edges$class <- ifelse(edges$cor>0, "Positive ",
                        "Negative")

  g <- tbl_graph(nodes = nodes, edges = edges)
  class(g) #[1] "tbl_graph" "igraph"
  groupcolor <- mycolor[1:length(unique( Type2[,2]))]
  ###2. 绘制图形
  # 自定义颜色映射
  library(showtext)

  library(ggraph)
  library(ggplot2)
  #font_add('Arial', 'C:\\Users\\Lenovo\\Downloads\\arial\\arial.ttf')
  showtext_auto()
  new=paste(aaa,"cor_graph.pdf",sep="_")
  #pdf(new,height = 9,width = 10)

  gg = ggraph(g,layout='kk') +
    #ggraph(g,layout='linear',circular = FALSE) +
    #ggraph(g,layout='circle') +
    guides(edge_color = guide_legend(override.aes = list(edge_width = 3))) +
    geom_edge_bend(mapping = aes(edge_width = abs(cor),
                                 edge_color = class),
                   strength = 0.2,alpha = 0.5) +
    scale_edge_colour_manual(values = c("#00bdcd","#ee6363")) +
    scale_edge_width(range=c(0.4,1.5)) +

    geom_node_point(aes(fill = cluster),
                    shape=21,size=6) +
    scale_fill_manual(values = color74)+
    scale_shape_manual(values =21)+
    geom_node_text(aes(x = x*1, y=y*1, label=name),
                   angle=0,hjust=0.5, fontface="bold",size=5) +   #

    #scale_size_continuous(range = c(20, 1)) +  #

    theme_graph()+theme(text=element_text(family="sans"))+

    theme(
      legend.title  = element_text( size = 25),legend.text = element_text( size = 20))

  #ggsave( gg,filename ="111.png",height = 10,width =12.5,dpi=300)


  #dev.off()
  ggsave( gg,filename =paste( aaa,new,sep="/"),height = 15,width = 35,dpi=300)
  new2=paste(aaa,"cor_graph-2.pdf",sep="_")
  ggsave( gg,filename =paste( aaa,new2,sep="/"),height = 15,width = 20,dpi=300)
  new2=paste(aaa,"cor_graph-3.pdf",sep="_")
  ggsave( gg,filename =paste( aaa,new2,sep="/"),height = 15,width = 13,dpi=300)
}
