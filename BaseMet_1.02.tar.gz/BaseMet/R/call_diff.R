#' Title
#' @param group_sample
#' @param input_martix
#'
#' @return
#' @export
#'
#' @examples

call_diff <- function(group_sample, input_martix) {
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)

  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)

  rownames(rt)=rt[,1]
  rt=rt[,-1]

  Type=read.table(group_sample,header = F,sep = "\t",check.names=F)
  #rt=rt[,Type[,1]]

  group_list=Type[,2]
  rt=t(rt)
  rt=log2(rt+0.000000001)
  rt = rt[Type[,1],]
  data2 =data.frame()
  for(i in colnames(rt)){
    a = as.data.frame(cbind(expression=rt[ , i], gene=i, Subtype=group_list))
    a[ , 1] = as.numeric(a[ , 1])
    wilcoxon =t.test(expression ~ Subtype, data = a)
    # wilcoxon <- wilcox.test(expression ~ Subtype, data = a,paired = F)
    #wilcoxon<- kruskal.test(expression ~ Subtype, data = a)
    pValue = wilcoxon$p.value
    ##wilcoxon = aov(expression ~ Subtype, data = a)
    #sum=summary(wilcoxon)
    #pValue=sum[[1]][["Pr(>F)"]][1]

    #data = rbind(data, a)
    print(pValue)
    b= as.data.frame(cbind(i,pValue))
    data2= as.data.frame(rbind(data2,b))

  }
  data2[grep ("NaN",data2$pValue),2]=1

  fdr=p.adjust(
    data2[,2],  # P值列表
    method ="BH"                       # FDR校正的方法
  )

  data2$fdr=fdr
  #

  #
  ###FC
  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)

  rownames(rt)=rt[,1]
  rt=rt[,-1]

  rt=t(rt)
  Type=read.table(group_sample,header = F,sep = "\t",check.names=F)

  group_list=Type[,2]
  data =data.frame()
  rt = rt[Type[,1],]
  rt=rt+0.00000001
  group1 <- grep(Type[1,2], Type[,2])
  group2 <- grep(Type[nrow(Type),2], Type[,2])



  for(i in colnames(rt)){
    a = as.data.frame(cbind(expression=rt[ , i], gene=i, Subtype=group_list))
    a[ , 1] = as.numeric(a[ , 1])
    meana=mean(a[(group1),1])
    meanb=mean(a[(group2),1])
    fc = meanb/meana
    logfc=log2(fc)

    #data = rbind(data, a)
    print(logfc)
    b= as.data.frame(cbind(i,logfc))
    data= as.data.frame(rbind(data,b))

  }

  data3=cbind(data2,data[,2])
  colnames(data3)=c('id',"PValue","FDR","logFC")
  library("stringr")
  #aaa="cluster-cere56.txt"
  # write.table(data3, file= aaa,sep="\t",row.names=F,quote=F)

  aaa=paste(Type[nrow(Type),2],"vs",Type[1,2],sep="_")
  main_dir="./"
  sub_dir=aaa
  output_dir <- file.path(main_dir, sub_dir)
  dir.create(output_dir)
  new=paste(Type[nrow(Type),2],"vs",Type[1,2],"diff.txt",sep="_")
  write.table(data3, file=paste( aaa,new,sep="/"),sep="\t",row.names=F,quote=F)
  ######vol
  allDiff=data3

  allDiff[,2:4]=as.numeric( as.matrix( allDiff[,2:4]))
  new=paste(Type[nrow(Type),2],"vs",Type[1,2],"P-vol.pdf",sep="_")
  pdf(paste( aaa,new,sep="/"))

  xMax=max(allDiff$logFC)+1
  yMax=max(-log10(allDiff$PValue))+1
  plot( allDiff$logFC,-log10(allDiff$PValue), ylab="-log10(PValue)",xlab="logFC",
        main=aaa, xlim=c(-xMax,xMax),ylim=c(0,yMax),xaxs="i",pch=20, cex=1)
  diffSub=allDiff[allDiff$PValue<padj & allDiff$logFC>foldChange,]
  points( diffSub$logFC, -log10(diffSub$PValue),pch=20, col="red",cex=1)
  diffSub=allDiff[allDiff$PValue<padj & allDiff$logFC<(-foldChange),]
  points( diffSub$logFC, -log10(diffSub$PValue),pch=20, col="green",cex=1)
  abline(v=c(-foldChange,foldChange),h=1.3,lty=2,lwd=1.5)
  dev.off()



}
