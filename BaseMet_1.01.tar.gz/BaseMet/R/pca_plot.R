#' Title
#' @param ALLsample
#' @param input_martix
#'
#' @return
#' @export
#'
#' @examples


pca_plot <- function(input_martix,ALLsample){
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)
  library(readxl)
  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)

  rownames(rt)=rt[,1]
  rt=rt[,-1]

  Type=read.table(ALLsample,header = F,sep = "\t",check.names=F)
  rt=rt[,Type[,1]]

  group=factor(Type$V2,levels = C(unique(Type$V2)))
  rt=t(rt)
  rt=log2(rt+0.001)
  # rt=scale(rt)
  dt=as.matrix( rt)
  #group <- Type[,2]
  com1 <- prcomp(dt, center = TRUE,scale. = TRUE)
  summary(com1)
  df1<-com1$x
  head(df1)

  df1<-data.frame(df1,group)
  head(df1)
  summ<-summary(com1)

  xlab<-paste0("PC1(",round(summ$importance[2,1]*100,2),"%)")
  zlab<-paste0("PC3(",round(summ$importance[2,3]*100,2),"%)")
  ylab<-paste0("PC2(",round(summ$importance[2,2]*100,2),"%)")
  library(ggplot2)
  library(ggforce)
  PC=df1
  colnames(PC)[1:2] <- c("PC1","PC2")
  groupcolor <- mycolor[1:length(unique( Type[,2]))]
  names(groupcolor) <- unique( Type[,2])
  #colors <- c("red","#0072B2","#009E73" ,"yellow")
  library(ggplot2)
  library(ggrepel)
  library(tidyverse)
  #colors1 <- colors[as.numeric(as.factor(group))]
  df<-data.frame(PC[,1:2],group)

  p1<-ggplot(data = df,aes(x=PC1,y=PC2,color=group))+
    geom_point(size=4)+
    labs(x = paste0( xlab), y = paste0( ylab))+
    #guides(color=guide_legend(override.aes = list(size=5,shape=15)))+
    scale_color_manual(values = groupcolor)+
    #stat_ellipse(level = 0.95, linetype = 'solid',
    #linewidth = 1, show.legend = F) + #添加置信区间
    #scale_colour_gradientn(colours = c("blue", "purple", "red"))+
    theme_bw()
  # geom_text_repel(aes(label=rownames(df)),box.padding = unit(0.5,'line'))
  # p1

  ggsave(filename = "2DPCA.pdf",p1,height = 6, width=6.5 )

  library(scatterplot3d)
  #colors1 <- mycolor[as.numeric(as.factor(group))]
  # colors1 <- mycolor[as.numeric(factor(Type[,2],levels = group))]
  colors1 <- mycolor[as.numeric(group)]
  #############################

  df3=df1
  colnames(df3)[1:3]=c(xlab,ylab,zlab)
  pdf("3DPCA.pdf",height = 5, width=5)
  s3d <- scatterplot3d(df3[,1:3],
                       pch = 16,       # 点形状
                       color=colors1,   # 点颜色
                       cex.symbols = 1, # 点大小
                       scale.y=1
  )
  # 设置图例
  # text(s3d$xyz.convert(df3[, 1:3]*1.05), labels = rownames(df3),
  #      cex= 0.5, col = "black")

  dev.off()




}
