#' Title
#' @param group_meta
#' @param input_martix
#' @param group_sample
#' @return
#' @export
#'
#' @examples
kegg_plot <- function(input_martix,group_meta,group_sample){
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)
  Type=read.table(group_sample,header = F,sep = "\t",check.names=F)
  aaa=paste(Type[nrow(Type),2],"vs",Type[1,2],sep="_")
  gene_KEGG <- read.table('meta-kegg.txt' ,header=T,sep = "\t",colClasses="character")
  library("stringr")
  #aaa=str_split(input_martix,'[.]',simplify = T)[,c(1,2)]
  new=paste(aaa,"diff.txt",sep="_")
  diffgene=read.table(paste( aaa,new,sep="/"),sep="\t",check.names=F,header=T,quote ="")
  diffgene=diffgene[diffgene[,SELECT]<0.05 & (diffgene$logFC >foldChange |diffgene$logFC < -foldChange),]
  Type2=read_excel(group_meta,sheet = "Sheet1")
  Type2=as.data.frame(Type2)

  rownames(Type2)=Type2[,1]
  Type2=Type2[,-1]
  name=Type2[diffgene[,1],4]

  library(clusterProfiler)

  library(enrichplot)
  library(ggplot2)
  library(stringi)

  kk <- enricher( gene = name ,
                  TERM2GENE = gene_KEGG[c('Pathway', 'cpd_id')],  #背景基因集
                  TERM2NAME = gene_KEGG[c('Pathway', 'Description')],
                  pvalueCutoff =1, qvalueCutoff =1)
  p=dotplot(kk, color = "pvalue",showCategory = 30, font.size = 15)+
    scale_y_discrete(labels = function(x) str_wrap(x, width = 60))+labs(x="MetaRatio")
  p
  new=paste(aaa,"KEGG.pdf",sep="_")
  ggsave(filename = paste( aaa,new,sep="/"), plot = p, dpi = 400, width = 10, height = 10)
  new=paste(aaa,"KEGG.txt",sep="_")
  write.table(kk,file=paste( aaa,new,sep="/"),sep="\t",quote=F,row.names = F)
}
