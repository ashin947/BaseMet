#' Title
#' @param group_sample
#' @param input_martix
#' @param group_meta
#' @return
#' @export
#'
#' @examples

heatmap_cor <- function(group_sample, input_martix,group_meta) {
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)
   library(pheatmap)
  ##样本名在上
  #library(limma)

  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)

  rownames(rt)=rt[,1]
  rt=rt[,-1]


  data = rt
  Type=read.table(group_sample,header = F,sep = "\t",check.names=F)
  aaa=paste(Type[nrow(Type),2],"vs",Type[1,2],sep="_")
  Type2=read_excel(group_meta,sheet = "Sheet1")
  Type2=as.data.frame(Type2)
  for (i in 1:nrow(Type2) ){
    x=Type2[i,1]  # 赋值
    a=gsub('["]', '', x)  #去双引号
    Type2[i,1]=a  #给矩阵重新赋值
  }
  rownames(Type2)=Type2[,1]
  #rownames(Type2)=Type2[,4]
  Type2=Type2[,-1]
  #
  for (i in 1:nrow(Type2) ){
    x=Type2[i,2]  # 赋值
    a=gsub('["]', '', x)  #去双引号
    Type2[i,2]=a  #给矩阵重新赋值
  }
  for (i in 1:nrow(Type2) ){
    x=Type2[i,3]  # 赋值
    a=gsub('["]', '', x)  #去双引号
    Type2[i,3]=a  #给矩阵重新赋值
  }


  library("stringr")
  library(forcats)

  new=paste(aaa,"diff.txt",sep="_")
  diffgene=read.table(paste( aaa,new,sep="/"),sep="\t",check.names=F,header=T,quote ="")
  diffgene=diffgene[diffgene[,SELECT]<0.05 & (diffgene$logFC >foldChange |diffgene$logFC < -foldChange),]
  for (i in 1:nrow(diffgene) ){
    x=diffgene[i,1]  # 赋值
    a=gsub('["]', '', x)  #去双引号
    diffgene[i,1]=a  #给矩阵重新赋值
  }

  #sample=read.table("sample.txt",sep="\t",check.names=F,header=F,quote ="")
  #sample[,1] <- as.factor(sample[,1])
  #sample[,1]<- fct_inorder(sample[,1])
  diffgene=diffgene[order(diffgene[,4]),]
  #intersect=intersect(y=row.names(Type2), x =sample[,1])
  intersect=intersect(y=row.names(Type2), x =diffgene[,1])
  Type2=Type2[intersect,]
  Type3=Type2
  # rt=data[sample[,1],]
  rt=data[intersect,]
  rt=rt[,Type[,1]]

  rtlog=( log(rt+0.0000001))
  #rtlog=scale(rtlog)
  cluster=Type
  rownames(cluster) = cluster[ , 1]
  cluster=as.data.frame(cluster[,-1])
  colnames(cluster)[1]="Type"
  rownames(cluster)=Type[,1]
  #cluster$Type=factor(cluster$Type,levels = c("C","P"))
  cluster$Type=factor(cluster$Type,levels = c(Type[1,2],Type[nrow(Type),2]))
  new=paste(aaa,"heatmap.pdf",sep="_")
  color1 <- c("#0072B5FF","red")
  names(color1) <- c(cluster[1,1],cluster[nrow(cluster),1])
  ann_color <- list(Type= color1 )
  library(showtext)
  #font_add('Arial', 'C:\\Users\\Lenovo\\Downloads\\arial\\arial.ttf')
  showtext_auto()
  if(nrow(Type2)<= 5 & nrow(Type2)>0){ height=0.8+0.17*nrow(Type2)}
  if(nrow(Type2)<= 25 & nrow(Type2)>5){ height=0.5+0.17*nrow(Type2)}
  if( nrow(Type2)>25){height=0.5+0.12*nrow(Type2)}

  pdf(paste( aaa,new,sep="/"), height = height, width = 8)
  pheatmap(rtlog, annotation_col=cluster,
           #main = aaa,
           color = colorRampPalette(c("blue", "white", "red"))(50),
           cluster_cols =F,
           cluster_rows =F,
           fontsize=8,
           fontsize_row=8,
           scale="row",
           show_colnames=F,
           show_rownames=T,
           fontsize_col=3,
           border_color=NA,
           #kmeans_k = 3
           annotation_colors = ann_color
           #annotation_colors = ann_color
  )
  dev.off()
  ##

  ###

  #Type2=Type2[diffgene[,1],]
  Type2=Type2[order(Type2[,2]),]
  sortname=Type2[,3]
  Type2=as.data.frame(Type2[,2])
  #Type2=as.data.frame(Type2[,1:2])
  colnames(Type2)[1]="Group"
  #colnames(Type2)[1:2]=c("Group1","Group2")
  rownames(Type2)=sortname
  rtlog2=rtlog[sortname,]
  library(ggsci)

  groupcolor <- color74[1:length(unique( Type2[,1]))]
  names(groupcolor) <- unique( Type2[,1])

  ann_color2 <- list(Group = groupcolor
  )

  #
  ann_color_all = c(ann_color2,ann_color)

  library(ggsci)
  if(nrow(Type2)<= 5 & nrow(Type2)>0){ height=0.8+0.17*nrow(Type2)}
  if(nrow(Type2)<= 25 & nrow(Type2)>5){ height=0.8+0.17*nrow(Type2)}
  if( nrow(Type2)>25){height=0.8+0.12*nrow(Type2)}

  new=paste(aaa[1],"type-heatmap.pdf",sep="_")
  pdf(paste( aaa,new,sep="/"), height =  height, width = 9)

  pheatmap(rtlog2, annotation_col=cluster,
           #main = aaa,
           annotation_row = Type2,
           color = colorRampPalette(c("blue", "white", "red"))(50),
           cluster_cols =F,
           cluster_rows =F,
           fontsize=8,
           fontsize_row=8,
           scale="row",
           show_colnames=F,
           fontsize_col=3,
           border_color=NA,
           annotation_colors = ann_color_all
           #
           # annotation_colors = ann_color2
  )
  dev.off()

  Type3=Type3[order(Type3[,1]),]
  sortname=Type3[,3]

  Type3=as.data.frame(Type3[,1:2])
  colnames(Type3)[1:2]=c("Group1","Group2")
  rownames(Type3)=sortname
  rtlog3=rtlog[sortname,]
  library(ggsci)

  groupcolor <- color74[1:length(unique( Type3[,2]))]
  names(groupcolor) <- unique( Type3[,2])

  ann_color2 <- list(Group2 = groupcolor
  )

  groupcolor <- mycolor[1:length(unique( Type3[,1]))]
  names(groupcolor) <- unique( Type3[,1])
  ann_color1 <- list(Group1 = groupcolor)


  #
  ann_color_all = c(ann_color2,ann_color1,ann_color)

  library(ggsci)


  new=paste(aaa[1],"2type-heatmap.pdf",sep="_")
  pdf(paste( aaa,new,sep="/"), height =  height, width = 9)

  pheatmap(rtlog3, annotation_col=cluster,
           #main = aaa,
           annotation_row = Type3,
           color = colorRampPalette(c("blue", "white", "red"))(50),
           cluster_cols =F,
           cluster_rows =F,
           fontsize=8,
           fontsize_row=8,
           scale="row",
           show_colnames=F,
           fontsize_col=3,
           border_color=NA,
           annotation_colors = ann_color_all
           #
           # annotation_colors = ann_color2
  )
  dev.off()










  library(corrplot)
  library(ggplot2)
  rt1=t(rt)
  ###基因在上
  #  top25
  #  new=paste(Type[nrow(Type),2],"vs",Type[1,2],"diff.txt",sep="_")
  #  diffgene=read.table(paste( aaa,new,sep="/"),sep="\t",quote='',header = T)

  #  diffgene=diffgene[diffgene$PValue < 0.05,]
  #  diffgene=diffgene[(diffgene$logFC <= -0.585 | diffgene$logFC >= 0.585),]
  #  diffgene=diffgene[order( abs( diffgene[,"logFC"])  ),]
  #  diffgene=diffgene[  ((nrow(diffgene)-24): nrow(diffgene)), ]


  #  rt1_top25=as.data.frame( log2( t(rt)+0.0001))
  #  rt1_top25=rt1_top25[,diffgene[,1]]


  #  data_top <- cor (rt1_top25, method="spearman")

  #  testRes = cor.mtest(rt1_top25, method="spearman",conf.level = 0.95)
  #  col1<-colorRampPalette(c("blue", "white", "red"))(50)
  #  new=paste(aaa,"cor_top25.pdf",sep="_")

  #  height=16
  #  pdf(paste( aaa,new,sep="/"), height = height, width = height)
  #  corrplot(data_top, method = "ellipse", addCoef.col ='black',
  #           type = "upper",order = "AOE",p.mat = testRes$p,insig = "blank",
  #           tl.col = "black", tl.cex = 1.3, tl.srt = 45,col = col1
  #  )
  #  dev.off()



  data <- cor (rt1, method="spearman")
  new=paste(aaa,"cor.txt",sep="_")
  write.table(data,file=paste( aaa,new,sep="/"),sep = "\t",row.names=F,quote=F)
  testRes = cor.mtest(rt1, method="spearman",conf.level = 0.95)
  col1<-colorRampPalette(c("blue", "white", "red"))(50)
  new=paste(aaa,"cor.pdf",sep="_")
  a=(nrow(Type2)-15)/10;height=8+a*5
  pdf(paste( aaa,new,sep="/"), height = height, width = height)
  corrplot(data, method = "ellipse", addCoef.col ='black',
           type = "upper",order = "AOE",p.mat = testRes$p,insig = "blank",
           tl.col = "black", tl.cex = 1.3, tl.srt = 45,col = col1
  )


  dev.off()


  library(tidyverse)
  data[upper.tri(data)] = NA
  data=reshape2::melt(data, na.rm=T)


  p=testRes[["p"]]
  p[upper.tri(p)] = NA
  p=reshape2::melt(p, na.rm=T)

  result3=cbind(data,p[,3])
  colnames(result3)=c("from","to","cor","p")

  new=paste(aaa,"cor_graph.txt",sep="_")
  write.table(result3,file=paste( aaa,new,sep="/"),sep = "\t",row.names=F,quote=F)
}
