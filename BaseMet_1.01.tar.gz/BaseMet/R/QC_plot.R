#' Title
#' @param group_sample
#' @param input_martix
#' @param group_meta
#' @return
#' @export
#'
#' @examples
QC_plot <-  function(group_sample, input_martix,group_meta){
  library(ggsci)
  library(readxl)
  color11<-pal_lancet("lanonc",alpha = 0.7)(9)
  color22<-pal_npg("nrc",alpha = 0.7)(10)
  library(RColorBrewer)
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  color74 = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))

  mycolor=c(color11,color22)
   library("PerformanceAnalytics")
  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)
  rownames(rt)=rt[,1]
  rt=rt[,-1]
  row <- grep("QC", colnames(rt))
  #for(j in 1:row){sample1 <- cbind(sample1, rt[,j])}
  rt=log( rt[,c(row)]+0.001)
  pdf("qc.pdf", height = 8, width = 8)
  chart.Correlation(rt, histogram=TRUE,method = "spearman", pch=19)
  dev.off()

  library(readxl)
  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)
  rownames(rt)=rt[,1]
  rt=rt[,-1]
  #
  Type=read.table(ALLsample,header = F,sep = "\t",check.names=F)
  group=factor(Type[,2])
  rt=rt[,Type[,1]]
  rt=t(rt)
  rt=cbind(rt,Type[,2])
  dataa=cbind(name=unique(Type[,2]),rt[(1:length( unique(Type[,2]))),])
  rownames(dataa)=dataa[,1]
  dataa=dataa[,-1]
  dataa=as.data.frame(dataa)
  rt=as.data.frame(rt)
  colnames(rt)[ncol(rt)]="group"
  for(i in 1:(ncol(rt)-1) ){

    for(j in unique(Type[,2])){
      rtt=rt
      rtt=rtt[rtt$group==j,]
      rtt[,i]=as.numeric(rtt[,i])
      mean_x <- mean(rtt[,i])
      sd_x <- sd(rtt[,i])
      cv <- (sd_x / mean_x)
      dataa[j,i]=cv
    }

  }

  library(ggplot2)
  library(reshape2)
  df=data.frame()
  for(i in unique(Type[,2])){
    df1=t(rbind(name=i,cv=dataa[i,]))
    df1=df1[-ncol(rt),]
    df=rbind(df,df1)
  }
  df$cv=as.numeric(df$cv)
  df$name=factor(df$name)
  df=df[df$cv<=1,]

  df$name=factor(df$name,levels = C(unique(df$name)))
  groupcolor <- mycolor[1:length(unique( df$name))]
  # 绘图
  p=ggplot(df,
           aes(
             x=cv,
             color=name
           ))+scale_color_manual(values=groupcolor) +theme_bw()+
    stat_ecdf( # ggplot2中的经验累积分布函数
      size=1   # 线条粗细
    )

  ggsave(filename = "CV.pdf", plot = p, dpi = 400, width = 6, height =6)

  rt=read_excel(input_martix,sheet = "Sheet1")
  rt=as.data.frame(rt)
  rownames(rt)=rt[,1]
  rt=log2(rt[,-1]+0.001)
  row <- grep("QC", colnames(rt))

  datamean =apply(rt,2,mean)
  datamean
  mean1 =mean(datamean)
  dataU=sd(datamean)
  #UCL=mean1 +dataU
  #LCL=mean1 -dataU
  max=max(datamean)+1
  min=min(datamean)-1
  pdf("Area of peak.pdf", height = 5, width = 5)
  plot(datamean,type = "b",col="blue",pch=15,ylim = c(min,max),xlab = "order",ylab = "Area of peak")

  points(x=row,y=datamean[row],type="p",col="green",pch=15)
  abline(h=mean1,col="red",lty=2)
  #abline(h=UCL,col="red")
  #abline(h=LCL,col="red")
  abline(h=(mean1 +2*dataU),col="red")
  abline(h=mean1 -2*dataU,col="red")
  dev.off()


}
